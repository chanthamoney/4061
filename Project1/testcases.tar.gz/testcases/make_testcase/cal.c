void cal()
{
}
