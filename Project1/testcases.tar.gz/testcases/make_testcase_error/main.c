#include <stdio.h>

void parse();
void cal();


int main()
{	
	parse();
	cal();
	
	return 0;
}

