# CSCI-4061
## CSci4061 S2018 Assignment 1
#### login: cselabs login name (login used to submit)
#### date: 10/05/2018
#### name: Cassandra Chanthamontry, Jogey Vang, Ounngy Ing 
#### id: chant077, vang2351, ingxx006

Cassandra: Develop code and algorithm.

Jogey: Develop code and algorithm.

Ounngy: Tested algorithm and documentation.

